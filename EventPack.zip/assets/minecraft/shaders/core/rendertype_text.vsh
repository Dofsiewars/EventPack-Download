#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

// Marker alpha baked into the top-left 2x2 texels of
// assets/minecraft/textures/font/loading_screen.png.
#define LB_MARKER 250
#define LB_MAX_STYLE 7

// Source size of that texture. Bitmap glyphs are stored in the font atlas at
// their source resolution, so this gives us the glyph's atlas rectangle without
// having to guess where the atlas packer put it. Must match LB_GLYPH_PX in
// shaders/include/loading_bars.glsl and SIZE in tools/bake_logo.py.
#define LB_GLYPH_PX 80.0

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

flat out int lbStyle;
flat out float lbProgress;
flat out float lbHue;
flat out float lbAlpha;
flat out vec2 lbGuiSize;
flat out vec2 lbUvOrigin;
flat out vec2 lbUvSize;

// Quad corner order used by Minecraft's text batches, in UV space (y down).
const vec2[4] LB_CORNERS = vec2[4](
    vec2(0.0, 0.0), vec2(0.0, 1.0), vec2(1.0, 1.0), vec2(1.0, 0.0)
);

void main() {
    vec4 vertex = vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;

    lbStyle = 0;
    lbProgress = 0.0;
    lbHue = 0.0;
    lbAlpha = 1.0;
    lbGuiSize = vec2(1.0);
    lbUvOrigin = vec2(0.0);
    lbUvSize = vec2(1.0);

    gl_Position = ProjMat * ModelViewMat * vertex;

    // Reconstruct the glyph's rectangle in the atlas from this vertex's corner.
    vec2 corner = LB_CORNERS[gl_VertexID % 4];
    vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
    vec2 uvSize = LB_GLYPH_PX * texel;
    vec2 uvOrigin = UV0 - corner * uvSize;

    // The marker sits one texel in, so this lands well inside the 2x2 block
    // whatever the atlas packer did.
    int marker = int(round(textureLod(Sampler0, uvOrigin + texel, 0.0).a * 255.0));
    if (marker != LB_MARKER) {
        return;
    }

    // From here on this vertex belongs to a loading-screen glyph and must never
    // be drawn as normal text.

    // Only ever expand in an orthographic (GUI) pass.
    if (ProjMat[3][3] != 1.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    }

    // Red channel carries 128 + style. Vanilla's text shadow is (rgb & 0xFCFCFC) >> 2,
    // so a shadow copy can never reach 128 and is rejected here.
    int red = int(round(Color.r * 255.0));
    int style = red - 128;
    if (red < 128 || style < 1 || style > LB_MAX_STYLE || Color.a <= 0.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    }

    lbStyle = style;
    lbProgress = round(Color.g * 255.0) / 255.0;
    lbHue = round(Color.b * 255.0);
    // Follow the text's own alpha so action bar / chat fade-outs fade it too.
    lbAlpha = Color.a;
    lbUvOrigin = uvOrigin;
    lbUvSize = uvSize;

    // Orthographic GUI projection: 2 / (right - left) and 2 / (top - bottom),
    // the latter negative because Minecraft's GUI y axis points down.
    lbGuiSize = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);

    // Cover the screen while keeping the glyph's original depth so the overlay
    // still layers correctly against the rest of the GUI.
    float ndcDepth = gl_Position.z / gl_Position.w;
    gl_Position = vec4(corner.x * 2.0 - 1.0, 1.0 - corner.y * 2.0, ndcDepth, 1.0);
}
